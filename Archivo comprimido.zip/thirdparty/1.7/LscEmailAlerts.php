<?php
/**
 * LiteSpeed Cache for Prestashop.
 *
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see https://opensource.org/licenses/GPL-3.0 .
 *
 * @author   LiteSpeed Technologies
 * @copyright  Copyright (c) 2017 LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @license     https://opensource.org/licenses/GPL-3.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use LiteSpeed\Cache\Config\CacheConfig as Conf;
use LiteSpeed\Cache\Esi\EsiModuleConfig as EsiConf;

class LscEmailAlerts extends LscIntegration
{
    const NAME = 'ps_emailalerts';

    protected function init()
    {
        $confData = [
            EsiConf::FLD_PRIV => 0,
            EsiConf::FLD_HOOK_METHODS => 'hookDisplayProductAdditionalInfo',
            EsiConf::FLD_ONLY_CACHE_EMPTY => 1,
            EsiConf::FLD_TEMPLATE_ARGUMENT => 'product.id_product,product.id_product_attribute',
        ];
        $this->esiConf = new EsiConf(self::NAME, EsiConf::TYPE_BUILTIN, $confData);

        return $this->registerEsiModule();
    }
}

LscEmailAlerts::register();
